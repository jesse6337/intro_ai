import gui
def main():
    gui.GUI()
main()
