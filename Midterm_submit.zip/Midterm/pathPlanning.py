class path:
    def __init__(self):
        pass