readings = ['g','r','g','g','r','g','g','r','g','r',]
moves = [[1,0],[1,0],[1,0], [1,0],[1,0],[1,0],[0,1], [1,0],[0,-1]]
readings = []
moves = []
def add_readings(reading):
    readings.append(reading)
def add_moves(move):
    moves.append(move)